beginlog0 = ("Welcome to Nova Numbers' Large Random Number Generator")
beginlog = ("This Program will output an integer from 0-10000, You can order up to 5 numbers without rerunning the program.")
endinglog = ("If you need to order more large random numbers, rerun the program for another 5 numbers! Thanks for using my tools!")
print (beginlog0)
print (beginlog)
begin = input ("Press enter to order a large numeral")


import random

order = random.randint(0,10000)
print (order)

another = input ("Press enter to generate your next large numeral")
order = random.randint(0,10000)
print (order)

another = input ("Press enter to generate your next large numeral")
order = random.randint(0,10000)
print (order)

another = input ("Press enter to generate your next large numeral")
order = random.randint(0,10000)
print (order)

another = input ("Press enter to generate your next large numeral")
order = random.randint(0,10000)
print (order)

print (endinglog)