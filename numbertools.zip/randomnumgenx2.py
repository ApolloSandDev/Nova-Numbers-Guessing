startlog = ("Welcome to Nova Numbers' Random Number Generator")
startlogtwo = ("This Program will output an integer from 0-100, counting by increments of 2 (you can only get even integers) You can generate up to 10 numbers without rerunning the program.")
endinglog = ("If you need more random numbers, rerun the program for another 10.")
print (startlog)
print (startlogtwo)
begin = input ("Press enter to generate your even integer")


import random

randomnum = random.randrange(0,100, 2)
print (randomnum)

another = input ("Press enter to generate your next integer")
randomnum = random.randrange(0,100, 2)
print (randomnum)

another = input ("Press enter to generate your next integer")
randomnum = random.randrange(0,100, 2)
print (randomnum)

another = input ("Press enter to generate your next integer")
randomnum = random.randrange(0,100, 2)
print (randomnum)

another = input ("Press enter to generate your next integer")
randomnum = random.randrange(0,100, 2)
print (randomnum)

another = input ("Press enter to generate your next integer")
randomnum = random.randrange(0,100, 2)
print (randomnum)

another = input ("Press enter to generate your next integer")
randomnum = random.randrange(0,100, 2)
print (randomnum)

another = input ("Press enter to generate your next integer")
randomnum = random.randrange(0,100, 2)
print (randomnum)

another = input ("Press enter to generate your next integer")
randomnum = random.randrange(0,100, 2)
print (randomnum)

another = input ("Press enter to generate your next integer")
randomnum = random.randrange(0,100, 2)
print (randomnum)

another = input ("Press enter to generate your next integer")
randomnum = random.randrange(0,100, 2)
print (randomnum)

print (endinglog)