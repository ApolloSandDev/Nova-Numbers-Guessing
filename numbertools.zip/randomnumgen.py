startlog = ("Welcome to Nova Numbers' Random Number Generator")
startlogtwo = ("This Program will output an integer from 0-100. You can generate up to 10 numbers without rerunning the program.")
endinglog = ("If you need more random numbers, rerun the program for another 10.")
print (startlog)
print (startlogtwo)
begin = input ("Press enter to generate your integer")


import random

randomnum = random.randint(0,100)
print (randomnum)

another = input ("Press enter to generate your next integer")
randomnum = random.randint(0,100)
print (randomnum)

another = input ("Press enter to generate your next integer")
randomnum = random.randint(0,100)
print (randomnum)

another = input ("Press enter to generate your next integer")
randomnum = random.randint(0,100)
print (randomnum)

another = input ("Press enter to generate your next integer")
randomnum = random.randint(0,100)
print (randomnum)

another = input ("Press enter to generate your next integer")
randomnum = random.randint(0,100)
print (randomnum)

another = input ("Press enter to generate your next integer")
randomnum = random.randint(0,100)
print (randomnum)

another = input ("Press enter to generate your next integer")
randomnum = random.randint(0,100)
print (randomnum)

another = input ("Press enter to generate your next integer")
randomnum = random.randint(0,100)
print (randomnum)

another = input ("Press enter to generate your next integer")
randomnum = random.randint(0,100)
print (randomnum)

another = input ("Press enter to generate your next integer")
randomnum = random.randint(0,100)
print (randomnum)

print (endinglog)

